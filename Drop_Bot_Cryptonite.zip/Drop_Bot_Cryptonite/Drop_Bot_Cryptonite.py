from selenium.webdriver.support.ui import WebDriverWait
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import re
import time
from time import sleep
import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import pathlib

# VARIABLES PERSONALISEES -------------
# Articles au prix max souhaités, enlevé le # devant la ligne pour que l'article en question soit pris en compte
devise = "EUR"
Articles = {
    'RTX 3060' : 500,
    'RTX 3060 Ti' : 650,
    #'RTX 3070' : 700,
    #'RTX 3070 Ti' : 1200,
    'RTX 3080' : 1250,
    #'RTX 3080 Ti' : 1550,
    'RTX 3090' : 1500,
    #'RX 6800' : 1100,
    #'RX 6700' : 630,
    #'RX 6600' : 350,
    'RX 5700' : 400
}

# L'URL sur le quel les articles désiré s'affiche
url = 'https://www.ldlc-pro.ch/pieces/carte-graphique/c5413/+fv121-17714,17715,18293,19183,19184,19185,19339,19340,19365,19367,19674.html?sort=aviable,1#filterlist'

# Envoie de mail, utilisant Gmail par exemple
sender_email = "mon@mail.com"
rec_email = "mon@mail.com"
password = "mon_pass"

# FIN DES VARIABLES -------------

path = str(pathlib.Path().resolve())+"/chromedriver.exe"
browser = webdriver.Chrome(path)
browser.get(url)
sleep(2)
count = 2 # Les Xpath commence par 2 et pas 1
listArticleDispo = []

while True:
    try:
        # Recherche du titre d'article
        Titre = '/html/body/div[1]/div[2]/div[2]/div[4]/div[2]/table/tbody/tr['+str(count)+']/td[3]/h3/a'
        TitreCible = browser.find_element_by_xpath(Titre)
        Titre = TitreCible.get_attribute("innerHTML").splitlines()[0]

        # Recherche de son prix
        Prix = '/html/body/div[1]/div[2]/div[2]/div[4]/div[2]/table/tbody/tr['+str(count)+']/td[6]/span'
        Prix = browser.find_element_by_xpath(Prix)
        Prix = Prix.get_attribute("innerHTML").splitlines()[0]
        Prix = ''.join((filter(lambda x: x not in ['<', '>', 's', 'u', 'p','/','b','C','H','F',"'"], Prix)))
        Prix = float(Prix)
        Prix = round(Prix*1.077, 2)

        #Recherche disponibilité
        Disponibilite = '/html/body/div[1]/div[2]/div[2]/div[4]/div[2]/table/tbody/tr['+str(count)+']'
        Disponibilite = browser.find_element_by_xpath(Disponibilite)
        Disponibilite = Disponibilite.get_attribute("innerHTML")
        Disponibilite = re.search('alt="" title="(.*)"></span>', Disponibilite).group(1)

        #print(Titre, Prix)
        # Si disponible
        if Disponibilite != 'Rupture':
            for carte, prixCarte in Articles.items():
                    if carte in Titre and Prix <= prixCarte:
                        print(carte + f" à {devise}" + str(Prix) + ' | Disponibilité : ' + Disponibilite)

                        # sauv. le lien de l'article
                        text = TitreCible.get_attribute('href')

                        # Si l'article selectionné en stock n'est pas dans la liste d'article deja annoncé.
                        if Titre not in listArticleDispo:
                            # Ouvre le nouvel article dans une nouvelle fenêtre
                            browser_article = webdriver.Chrome(path)
                            browser_article.get(text)

                            message = MIMEMultipart("alternative")
                            message["Subject"] = carte + f" à {devise}" + str(Prix) + " | Disponibilité : " + Disponibilite
                            message["From"] = sender_email
                            message["To"] = rec_email
                            
                            part1 = MIMEText(text, "plain")
                            message.attach(part1)

                            # Create secure connection with server and send email
                            context = ssl.create_default_context()
                            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
                                server.login(sender_email, password)
                                server.sendmail(
                                    sender_email, rec_email, message.as_string()
                                )
                            
                            #Ajout de l'article à la liste des articles déja annoncé
                            listArticleDispo.append(Titre)
                            
                            # Attente de 2 secondes avant prochain envoie de mail
                            sleep(2)
                     
                        
        else:
            print('### Fin des articles en stock ###')
            count = 2
            sleep(30) #Rafraichissement de la page après 30 secondes d'attente
            browser.get(url)
            sleep(2)
        #pageFiltree = browser.current_url
        count += 1
    
    except Exception as e:
        print("Exception",e)
        print('### FIN DE RECHERCHE ###')
        browser.get(url)
        sleep(2)
        count = 2
